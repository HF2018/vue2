<template>
  <div>
      <h1>短信营销</h1>
      <h1>{{aboutMsg}}</h1>
  </div>
</template>
<script>
export default {
  data () {
      return {
          aboutMsg: '短信营销'
      }
  }
}
</script>

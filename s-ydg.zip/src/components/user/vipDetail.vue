<template>
  <div>
      <h1>会员详情</h1>
      <h1>{{aboutMsg}}</h1>
  </div>
</template>
<script>
export default {
  data () {
      return {
          aboutMsg: '会员详情'
      }
  }
}
</script>
